==========
gnss_plots
==========

License: GPLv3

``gnss-plots`` es un paquete que permite hacer gráficos de series de tiempo,
consultado coordenadas GNSS de estaciones del CSN a una base de datos RethinkDB.
Útil para uso interno.

``gnss-plots`` fue desarrollado en el
`Centro Sismologico Nacional <http://www.csn.uchile.cl>`_ de la
Universidad de Chile.

----

Author & Maintainer: Francisco del Campo R., fdelcampo@csn.uchile.cl
