=========
gnss_redb
=========

License: GPLv3

``gnss_redb`` es un paquete que permite interactuar con bases de datos
RethinkDB *ad-hoc* con coordenadas y desplazamientos de estaciones del CSN.
Útil para uso interno.

``gnss_redb`` fue desarrollado en el
`Centro Sismologico Nacional <http://www.csn.uchile.cl>`_ de la
Universidad de Chile.

----

Author & Maintainer: Francisco del Campo R., fdelcampo@csn.uchile.cl
