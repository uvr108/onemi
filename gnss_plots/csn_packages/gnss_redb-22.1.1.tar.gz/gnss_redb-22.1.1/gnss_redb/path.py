from os.path import join, dirname

ref_coords_file = join(dirname(dirname(__file__)), 'ref_coords/gnss_network')
