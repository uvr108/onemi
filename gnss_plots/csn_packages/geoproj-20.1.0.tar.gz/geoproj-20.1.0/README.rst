===========
``geoproj``
===========

License: GPLv3

.. Documentation: http://www.example.com

This package allows to transform between geographic coordinates and apply
cartographic projections.

``geoproj`` has been developed at the
`Centro Sismologico Nacional <http://www.csn.uchile.cl>`_ of
Universidad de Chile.


Este paquete permite transformar entre coordenadas geográficas y aplicar
proyecciones cartograficas.

``geoproj`` fue desarrolado en el
`Centro Sismologico Nacional <http://www.csn.uchile.cl>`_ de la
Universidad de Chile.


.. Usage
   -----

.. The file should use UTF-8 encoding and be written using `reStructuredText
   <http://docutils.sourceforge.net/rst.html>`_. It
   will be used to generate the project webpage on PyPI and will be displayed as
   the project homepage on common code-hosting services, and should be written for
   that purpose.
